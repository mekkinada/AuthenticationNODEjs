
dbPassword = 'mongodb+srv://authentication:authentication@cluster0.bkvds.mongodb.net/test?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
