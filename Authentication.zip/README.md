# Node.js AND Passport Login

This is a user login and registration app using Node.js, Express, Passport, Mongoose, EJS and some other packages.

>>>>> Version: 1.0.0

# Or run with Nodemon
$ npm run dev

# Visit http://localhost:5000

